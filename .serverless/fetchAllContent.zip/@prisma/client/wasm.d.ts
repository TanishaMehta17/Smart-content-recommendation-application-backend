export * from '.prisma/client/wasm'
